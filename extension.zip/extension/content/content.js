(() => {
  if (document.getElementById("hiretrail-fab")) return;
  const core = window.HireTrailExtractionCore;
  const extractorConfig = window.HireTrailExtractorsConfig;
  if (!core || !extractorConfig?.buildExtractorRegistry) return;
  let lastTrackedUrl = "";
  let isFabInitialized = false;
  const FAB_TOP_RATIO_KEY = "fabTopRatio";

  const scrapers = {
    "linkedin.com": () => {
      // Scope selectors to LinkedIn's own containers to avoid third-party extension
      // injections (e.g., Jobright) that add their own h1/h2 elements into the DOM.
      const topCard = document.querySelector(".job-details-jobs-unified-top-card__container--two-pane")
        || document.querySelector(".jobs-unified-top-card");

      const title = topCard?.querySelector(".job-details-jobs-unified-top-card__job-title h1")?.textContent?.trim()
        || topCard?.querySelector(".job-details-jobs-unified-top-card__job-title")?.textContent?.trim()
        || topCard?.querySelector("h1 a")?.textContent?.trim()
        || topCard?.querySelector("h1")?.textContent?.trim()
        || document.querySelector(".job-details-jobs-unified-top-card__job-title")?.textContent?.trim() || "";

      const company = topCard?.querySelector(".job-details-jobs-unified-top-card__company-name a")?.textContent?.trim()
        || topCard?.querySelector(".job-details-jobs-unified-top-card__company-name")?.textContent?.trim()
        || document.querySelector(".jobs-unified-top-card__company-name")?.textContent?.trim() || "";

      // For JD, only read LinkedIn's own description content, not injected elements
      const jdEl = document.querySelector(".jobs-description__content .jobs-box__html-content")
        || document.querySelector("#job-details")
        || document.querySelector(".jobs-description__content");
      const jobDescription = jdEl?.innerText?.trim() || "";

      const location = topCard?.querySelector(".tvm__text")?.textContent?.trim()
        || topCard?.querySelector(".job-details-jobs-unified-top-card__bullet")?.textContent?.trim()
        || document.querySelector(".tvm__text")?.textContent?.trim() || "";

      const salary = document.querySelector("[class*='salary']")?.textContent?.trim()
        || document.querySelector(".job-details-jobs-unified-top-card__job-insight span")?.textContent?.trim() || "";

      return { title, company, jobDescription, location, salary, jobType: "" };
    },
    "indeed.com": () => {
      const container = document.querySelector(".jobsearch-ViewjobPaneWrapper")
        || document.querySelector(".jobsearch-JobComponent");

      const title = container?.querySelector('[data-testid="jobsearch-JobInfoHeader-title"]')?.textContent?.trim()
        || container?.querySelector("h2.jobsearch-JobInfoHeader-title")?.textContent?.trim()
        || document.querySelector('[data-testid="jobsearch-JobInfoHeader-title"]')?.textContent?.trim() || "";

      const company = container?.querySelector('[data-testid="inlineHeader-companyName"] a')?.textContent?.trim()
        || container?.querySelector('[data-testid="inlineHeader-companyName"]')?.textContent?.trim()
        || document.querySelector(".jobsearch-InlineCompanyRating-companyHeader")?.textContent?.trim() || "";

      const location = container?.querySelector('[data-testid="inlineHeader-companyLocation"]')?.textContent?.trim()
        || document.querySelector('[data-testid="jobsearch-JobInfoHeader-companyLocation"]')?.textContent?.trim()
        || document.querySelector('[data-testid="job-location"]')?.textContent?.trim() || "";

      const salary = document.querySelector("#salaryInfoAndJobType span")?.textContent?.trim()
        || document.querySelector(".salary-snippet")?.textContent?.trim() || "";

      const jobType = document.querySelector('#salaryInfoAndJobType .css-1u1g3ig')?.textContent?.trim()
        || document.querySelector(".jobsearch-JobMetadataHeader-item")?.textContent?.trim() || "";

      return { title, company, jobDescription: document.querySelector("#jobDescriptionText")?.innerText?.trim() || "", location, salary, jobType };
    },
    "greenhouse.io": () => {
      // New Greenhouse layout uses .job__title h1, old uses .app-title
      const title = document.querySelector(".job__title h1")?.textContent?.trim()
        || document.querySelector(".app-title")?.textContent?.trim()
        || document.querySelector(".job-post-container h1")?.textContent?.trim() || "";

      const company = document.querySelector(".company-name")?.textContent?.trim()
        || document.querySelector('.job-post-container .logo img')?.alt?.replace(/\s*logo\s*/i, "")?.trim() || "";

      const jobDescription = document.querySelector(".job__description")?.innerText?.trim()
        || document.querySelector("#content .body")?.innerText?.trim()
        || document.querySelector("#content")?.innerText?.trim() || "";

      const location = document.querySelector(".job__location")?.textContent?.trim()
        || document.querySelector(".location")?.textContent?.trim() || "";

      return { title, company, jobDescription, location, salary: "", jobType: "" };
    },
    "lever.co": () => ({
      title: document.querySelector(".posting-headline h2")?.textContent?.trim() || "",
      company: document.querySelector(".posting-headline .sort-by-time")?.textContent?.trim()
        || document.querySelector(".posting-headline a")?.textContent?.trim() || "",
      jobDescription: (document.querySelector('[data-qa="job-description"]') || document.querySelector(".section.page-centered"))?.innerText?.trim() || "",
      location: document.querySelector(".sort-by-location")?.textContent?.trim()
        || document.querySelector(".posting-categories .location")?.textContent?.trim() || "",
      salary: "",
      jobType: document.querySelector(".commitment")?.textContent?.trim() || "",
    }),
    "glassdoor.com": () => {
      // Glassdoor redesigned — title is now h1 inside the job details header
      const header = document.querySelector('[data-test="job-details-header"]')
        || document.querySelector(".JobDetails_jobDetailsHeader__Hd9M3");

      const title = header?.querySelector("h1")?.textContent?.trim()
        || document.querySelector('[data-test="job-title"]')?.textContent?.trim()
        || document.querySelector("#jd-job-title")?.textContent?.trim() || "";

      // Company name is inside the employer profile heading
      const company = header?.querySelector('[class*="EmployerProfile_employerNameHeading"] h4')?.textContent?.trim()
        || header?.querySelector('[class*="EmployerProfile_employerInfo"] h4')?.textContent?.trim()
        || document.querySelector('[data-test="employer-name"]')?.textContent?.trim() || "";

      // JD is inside a blurred/expandable container
      const jobDescription = document.querySelector('[class*="JobDetails_jobDescription"] > div')?.innerText?.trim()
        || document.querySelector('[data-test="description"]')?.innerText?.trim() || "";

      const location = document.querySelector('[data-test="location"]')?.textContent?.trim()
        || document.querySelector('[data-test="job-location"]')?.textContent?.trim() || "";

      const salary = document.querySelector('[data-test="detailSalary"]')?.textContent?.trim() || "";

      return { title, company, jobDescription, location, salary, jobType: "" };
    },
    "myworkdayjobs.com": () => {
      // Try JSON-LD structured data first (available before JS renders)
      const jsonLd = (() => {
        try {
          const script = document.querySelector('script[type="application/ld+json"]');
          if (script) return JSON.parse(script.textContent);
        } catch {}
        return null;
      })();

      // DOM selectors scoped to job details section to avoid third-party injections
      const jobDetails = document.querySelector('[data-automation-id="jobDetails"]');
      const title = jobDetails?.querySelector('[data-automation-id="jobPostingHeader"]')?.textContent?.trim()
        || document.querySelector('a[data-automation-id="jobTitle"]')?.textContent?.trim()
        || jsonLd?.title || "";

      const company = (() => {
        // Try JSON-LD hiringOrganization first
        if (jsonLd?.hiringOrganization?.name) return jsonLd.hiringOrganization.name;
        // Fall back to subdomain
        const sub = window.location.hostname.split(".")[0];
        return sub.charAt(0).toUpperCase() + sub.slice(1);
      })();

      const jobDescription = jobDetails?.querySelector('[data-automation-id="jobPostingDescription"]')?.innerText?.trim()
        || document.querySelector('[data-automation-id="richTextBody"]')?.innerText?.trim()
        || document.querySelector('[data-automation-id="jobPostingDescription"]')?.innerText?.trim()
        || jsonLd?.description || "";

      const location = document.querySelector('[data-automation-id="locations"] dd')?.textContent?.trim()
        || document.querySelector('[data-automation-id="jobPostingLocation"]')?.textContent?.trim()
        || document.querySelector('[data-automation-id="locations"]')?.textContent?.trim()
        || jsonLd?.jobLocation?.address?.addressLocality || "";

      const jobType = jsonLd?.employmentType || "";

      return { title, company, jobDescription, location, salary: "", jobType };
    },
  };
  const extractorRegistry = extractorConfig.buildExtractorRegistry(scrapers);

  // Wait for a selector to appear (for SPAs like Workday). Supports comma-separated selectors.
  function waitForSelector(selector, timeout = 8000) {
    return new Promise((resolve) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) { observer.disconnect(); resolve(el); }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { observer.disconnect(); resolve(null); }, timeout);
    });
  }

  function scrape() {
    const host = window.location.hostname;
    for (const extractor of extractorRegistry) {
      if (host.includes(extractor.domain)) return extractor.scrape();
    }
    return { title: document.title, company: "", jobDescription: "", location: "", salary: "", jobType: "" };
  }

  function scrapeWithFallback() {
    return core.scrapeWithFallback(scrape, document, window.location);
  }

  // Auto-detect Apply button clicks
  function setupApplyDetection() {
    const host = window.location.hostname;
    const selectors = extractorRegistry.find((extractor) => host.includes(extractor.domain))?.applySelectors || [];
    if (selectors.length === 0) return;

    let debounceTimer = null;
    document.body.addEventListener("click", async (e) => {
      const target = e.target;
      const match = selectors.some((sel) => target.closest(sel));
      if (!match) return;
      if (debounceTimer) return;
      debounceTimer = setTimeout(() => { debounceTimer = null; }, 5000);

      // Silently check auth & track
      try {
        const authRes = await chrome.runtime.sendMessage({ type: "CHECK_AUTH" });
        if (!authRes || !authRes.authenticated) return;
        const data = scrapeWithFallback();
        if (!core.isLikelyJobPage(
          data,
          window.location.hostname,
          window.location.pathname,
          document.body?.innerText?.slice(0, 3000) || "",
        )) return;
        if (lastTrackedUrl === data.url) return;
        const result = await chrome.runtime.sendMessage({ type: "TRACK_JOB", data });
        if (result && result.success) {
          lastTrackedUrl = data.url;
          showStatus("Auto-tracked!", "success");
        }
        // Silent on 409 duplicate
      } catch {
        // Extension context invalidated — ignore silently
      }
    }, true);
  }

  // For Workday SPA, wait for content to load before showing FAB
  const host = window.location.hostname;
  if (host.includes("myworkdayjobs.com")) {
    // Wait for any of the known Workday job detail elements to appear
    waitForSelector('[data-automation-id="jobTitle"], [data-automation-id="jobPostingHeader"], [data-automation-id="richTextBody"]', 8000).then(() => initFAB());
  } else {
    initFAB();
  }

  function initFAB() {
    if (isFabInitialized) return;
    isFabInitialized = true;
    // Create floating action button
    const fab = document.createElement("div");
    fab.id = "hiretrail-fab";
    fab.innerHTML = `
      <div style="
        position: fixed; right: 0; top: 10vh; z-index: 999999;
        width: 52px; height: 52px;
        border-radius: 14px;
        border-top-right-radius: 0; border-bottom-right-radius: 0;
        background: #2b2f36; color: #fff;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer;
        box-shadow: 0 10px 26px rgba(0,0,0,0.22), 0 2px 0 rgba(255,255,255,0.05) inset;
        font-weight: 800; font-size: 16px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        transition: box-shadow 0.2s ease, transform 0.2s ease, background 0.2s ease, filter 0.2s ease;
        touch-action: none;
      " id="hiretrail-btn" aria-label="HireTrail tracker">
        <span id="hiretrail-glyph" style="display:flex; align-items:center; justify-content:center;">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M12 2.4l1.35 5.35 4.95-2.5-2.5 4.95 5.35 1.35-5.35 1.35 2.5 4.95-4.95-2.5L12 21.6l-1.35-5.35-4.95 2.5 2.5-4.95L2.85 12l5.35-1.35-2.5-4.95 4.95 2.5L12 2.4z"
              fill="#D7FF3A" opacity="0.98"/>
            <path d="M12 2.4l1.35 5.35 4.95-2.5-2.5 4.95 5.35 1.35-5.35 1.35 2.5 4.95-4.95-2.5L12 21.6l-1.35-5.35-4.95 2.5 2.5-4.95L2.85 12l5.35-1.35-2.5-4.95 4.95 2.5L12 2.4z"
              stroke="#D7FF3A" stroke-width="0.6" stroke-linejoin="round"/>
          </svg>
        </span>
      </div>
    `;
    document.body.appendChild(fab);

    const btn = document.getElementById("hiretrail-btn");
    const glyph = document.getElementById("hiretrail-glyph");
    let dragState = {
      pointerId: null,
      dragging: false,
      moved: false,
      startY: 0,
      startTop: 0,
    };

    function setFabVisual(state) {
      if (!btn || !glyph) return;
      const setText = (t) => { glyph.textContent = t; };
      const setStar = () => {
        glyph.innerHTML = `
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M12 2.4l1.35 5.35 4.95-2.5-2.5 4.95 5.35 1.35-5.35 1.35 2.5 4.95-4.95-2.5L12 21.6l-1.35-5.35-4.95 2.5 2.5-4.95L2.85 12l5.35-1.35-2.5-4.95 4.95 2.5L12 2.4z"
              fill="#D7FF3A" opacity="0.98"/>
            <path d="M12 2.4l1.35 5.35 4.95-2.5-2.5 4.95 5.35 1.35-5.35 1.35 2.5 4.95-4.95-2.5L12 21.6l-1.35-5.35-4.95 2.5 2.5-4.95L2.85 12l5.35-1.35-2.5-4.95 4.95 2.5L12 2.4z"
              stroke="#D7FF3A" stroke-width="0.6" stroke-linejoin="round"/>
          </svg>
        `;
      };

      if (state === "loading") {
        setText("…");
        btn.style.background = "#22262d";
        return;
      }
      if (state === "success") {
        setText("\u2713");
        btn.style.background = "#0f2a19";
        btn.style.color = "#d9ffe6";
        return;
      }
      if (state === "duplicate") {
        setText("\u2713");
        btn.style.background = "#2a240f";
        btn.style.color = "#fff1cc";
        return;
      }
      if (state === "error") {
        setText("!");
        btn.style.background = "#2b1414";
        btn.style.color = "#ffd7d7";
        return;
      }

      // idle
      setStar();
      btn.style.background = "#2b2f36";
      btn.style.color = "#ffffff";
    }

    function clampFabTop(topPx) {
      const margin = 8;
      const maxTop = Math.max(margin, window.innerHeight - btn.offsetHeight - margin);
      return Math.min(maxTop, Math.max(margin, topPx));
    }

    function applyFabTop(topPx) {
      btn.style.top = `${clampFabTop(topPx)}px`;
    }

    function persistFabTop(topPx) {
      const ratio = clampFabTop(topPx) / Math.max(window.innerHeight, 1);
      chrome.storage.local.set({ [FAB_TOP_RATIO_KEY]: ratio }).catch(() => {});
    }

    // Restore persisted vertical position for a consistent cross-site experience.
    chrome.storage.local.get([FAB_TOP_RATIO_KEY]).then((result) => {
      const ratio = typeof result[FAB_TOP_RATIO_KEY] === "number" ? result[FAB_TOP_RATIO_KEY] : 0.1;
      applyFabTop(window.innerHeight * ratio);
    }).catch(() => {
      applyFabTop(window.innerHeight * 0.1);
    });

    btn.addEventListener("pointerdown", (event) => {
      dragState.pointerId = event.pointerId;
      dragState.dragging = false;
      dragState.moved = false;
      dragState.startY = event.clientY;
      dragState.startTop = parseFloat(btn.style.top) || btn.getBoundingClientRect().top;
      btn.setPointerCapture(event.pointerId);
      btn.style.cursor = "grabbing";
      btn.style.transition = "box-shadow 0.1s ease, background 0.2s ease";
    });

    btn.addEventListener("pointermove", (event) => {
      if (dragState.pointerId !== event.pointerId) return;
      const deltaY = event.clientY - dragState.startY;
      if (!dragState.dragging && Math.abs(deltaY) > 4) {
        dragState.dragging = true;
        dragState.moved = true;
      }
      if (!dragState.dragging) return;
      event.preventDefault();
      applyFabTop(dragState.startTop + deltaY);
    });

    function finishDrag(event) {
      if (dragState.pointerId !== event.pointerId) return;
      if (dragState.dragging) {
        const currentTop = parseFloat(btn.style.top) || btn.getBoundingClientRect().top;
        persistFabTop(currentTop);
      }
      dragState.pointerId = null;
      dragState.dragging = false;
      btn.style.cursor = "pointer";
      btn.style.transition = "box-shadow 0.2s ease, transform 0.2s ease, background 0.2s ease";
      setTimeout(() => {
        dragState.moved = false;
      }, 120);
    }

    btn.addEventListener("pointerup", finishDrag);
    btn.addEventListener("pointercancel", finishDrag);
    window.addEventListener("resize", () => {
      const currentTop = parseFloat(btn.style.top) || btn.getBoundingClientRect().top;
      applyFabTop(currentTop);
    });

    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "translateX(-2px) scale(1.06)";
      btn.style.boxShadow = "0 14px 34px rgba(0,0,0,0.28), 0 2px 0 rgba(255,255,255,0.06) inset";
      btn.style.filter = "brightness(1.06)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "translateX(0) scale(1)";
      btn.style.boxShadow = "0 10px 26px rgba(0,0,0,0.22), 0 2px 0 rgba(255,255,255,0.05) inset";
      btn.style.filter = "none";
    });

    btn.addEventListener("click", async () => {
      if (dragState.moved || dragState.dragging) return;
      try {
        const authRes = await chrome.runtime.sendMessage({ type: "CHECK_AUTH" });
        if (!authRes || !authRes.authenticated) {
          showStatus("Log in via extension popup first", "error");
          return;
        }

        const data = scrapeWithFallback();
        if (!core.isLikelyJobPage(
          data,
          window.location.hostname,
          window.location.pathname,
          document.body?.innerText?.slice(0, 3000) || "",
        )) {
          showStatus("This page does not look like a job posting yet", "warning");
          return;
        }

        btn.style.opacity = "0.6";
        btn.style.pointerEvents = "none";
        setFabVisual("loading");

        const result = await chrome.runtime.sendMessage({ type: "TRACK_JOB", data });

        if (result && result.success) {
          lastTrackedUrl = data.url;
          showStatus("Tracked!", "success");
          setFabVisual("success");
        } else if (result && result.duplicate) {
          showStatus("Already tracked!", "warning");
          setFabVisual("duplicate");
        } else {
          showStatus(result?.error || "Failed", "error");
          setFabVisual("error");
        }
      } catch (err) {
        showStatus("Refresh page & try again", "error");
        setFabVisual("error");
      } finally {
        setTimeout(() => {
          setFabVisual("idle");
          btn.style.opacity = "1";
          btn.style.pointerEvents = "auto";
        }, 2000);
      }
    });

    setFabVisual("idle");

    // Setup auto-detect after FAB
    setupApplyDetection();
  }

  function showStatus(text, type) {
    const existing = document.getElementById("hiretrail-status");
    if (existing) existing.remove();

    const colors = {
      success: "#1e3a8a",
      error: "#e24b4a",
      warning: "#f59e0b",
    };

    const toast = document.createElement("div");
    toast.id = "hiretrail-status";
    toast.textContent = text;
    toast.style.cssText = `
      position: fixed; bottom: 84px; right: 24px; z-index: 999999;
      padding: 8px 16px; border-radius: 8px; font-size: 13px;
      font-family: -apple-system, sans-serif; font-weight: 500;
      color: #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      background: ${colors[type] || colors.error};
      animation: hiretrail-fadein 0.2s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  // Inject animation keyframe
  const style = document.createElement("style");
  style.textContent = `@keyframes hiretrail-fadein { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }`;
  document.head.appendChild(style);

  // SPA-safe route observer: reset auto-track guard whenever URL changes.
  let observedUrl = window.location.href;
  const routeObserver = new MutationObserver(() => {
    if (window.location.href !== observedUrl) {
      observedUrl = window.location.href;
      lastTrackedUrl = "";
    }
  });
  routeObserver.observe(document.documentElement, { childList: true, subtree: true });
})();
